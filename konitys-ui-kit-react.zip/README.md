# Konitys UI Kit (React)

UI kit light/clean : topbar plateforme + switcher d'app + sidebar interne repliable + pages templates.

## Prérequis
- Node 18+

## Lancer
```bash
npm install
npm run dev
```

## Où modifier
- Tokens: `src/styles.css` (variables CSS `--k-*`)
- Shell: `src/components/AppShell.jsx`
- Switcher: `src/components/KonitysSwitcher.jsx`
- Sidebar: `src/components/Sidebar.jsx`
- Templates: `src/pages/Hub.jsx` et `src/pages/BornesList.jsx`

## Notes
- Le switcher est en 1 ligne : `Konitys / App ▾` (comme demandé).
- La barre "Search… (Cmd+K)" est volontairement dans le switcher overlay (command palette à implémenter plus tard).
